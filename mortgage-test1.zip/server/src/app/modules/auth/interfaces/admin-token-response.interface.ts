export interface AdminTokenResponse {
  accessToken: string;
  refreshToken: string;
  accountId: string;
  login: string;
}
